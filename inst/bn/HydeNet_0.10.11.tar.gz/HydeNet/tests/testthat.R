library("testthat")
library("HydeNet")

test_check("HydeNet")